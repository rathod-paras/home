JU ENT Studio one-page website

Files:
- index.html
- assets/ju-ent-logo.png
- assets/ju-ent-logo-512.webp
- assets/ju-ent-hero-1920.webp
- assets/ju-ent-playstore-header-4096x2304.webp
- assets/block-merge-puzzle-icon.png
- assets/cozy-color-ropes-icon.png

Upload the full folder to GitHub Pages, Netlify, Vercel, or any static hosting service.
